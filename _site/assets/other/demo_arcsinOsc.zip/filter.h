#pragma once

class filter {
	public:
		// Initialization
		filter() {}
		filter(float sr);
		
		// Parameter setting
		void setup(float sr);
		void setCutoff(float c);
		void setResonance(float r);
		
		// Main routines
		float process(float in);
		
		~filter() {}
	private:
		float cutoff_;
		float resonance_;
		float buffer_[4];
		float sr_;
};