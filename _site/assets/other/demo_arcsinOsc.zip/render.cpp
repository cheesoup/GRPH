#include <Bela.h>
#include <libraries/Scope/Scope.h>
#include <libraries/Midi/Midi.h>
#include "oscillator.h"
#include "filter.h"

// Debug
bool print_on = true;
bool scope_on = true;


float* SR = new float;
float* lvl = new float{0.5};
float* freq = new float{220.0};
BasicWaves* osc = new BasicWaves;

// Variables for MIDI and oscilloscope
Midi midi;
const char* port = "hw:0,0,0";
Scope scope;

/*
MIDI CALLBACK
*/

void midiMessageCallback(MidiChannelMessage message, void* arg)
{
	if (print_on && (arg != NULL)) {
		rt_printf("Message from midi port %s ", (const char*) arg);
	}
	int controller = message.getDataByte(0);
	int value = message.getDataByte(1);
	float out;
	switch(controller) {
		case 8:
			*freq = 440.0 * powf(2.0, ((float)value - 69.0) / 12.0);
			if (print_on) rt_printf("freq: %f, midi: %d", freq, value);
			break;
		case 9:
			out = (float)value / 127.0;
			osc->setMorph(out);
			if (print_on) rt_printf("morph: %f, midi: %d", out, value);
			break;
		case 10:
			out = (float)value / 127.0;
			osc->setShape(out);
			if (print_on) rt_printf("shape: %f, midi: %d", out, value);
			break;
		case 11:
			out = fmaxf(1.0, (float)value)/ 128.0;
			osc->setPW(out);
			if (print_on) rt_printf("pw: %f, midi: %d", out, value);
			break;
		case 12:
			*lvl = (((float)value / 127.0) * ((float)value / 127.0)) * 0.5;
			break;
	}
	rt_printf("\n");
}

/*
END MIDI CALLBACK
*/

bool setup(BelaContext *context, void *userData)
{
	//Initialize oscillator
	*SR = context->audioSampleRate;
	osc->setup(SR);
	
	// Initialize Scope
	scope.setup(1, context->audioSampleRate);
	
	// Initialize MIDI
	midi.readFrom(port);
	midi.writeTo(port);
	midi.enableParser(true);
	midi.getParser()->setCallback(midiMessageCallback, (void*) port);
	return true;
}

void render(BelaContext *context, void *userData)
{
	for(unsigned int n = 0; n < context->audioFrames; n++) {
		
		float out = osc->process(*freq);
		out *= *lvl; // Adjust volume
		
		// Write to scope
		if (scope_on) scope.log(out);
		
		// Write to block
		for(unsigned int channel = 0; channel < context->audioOutChannels; channel++) {
			audioWrite(context, n, channel, out);
		}
	}
}

void cleanup(BelaContext *context, void *userData)
{
	delete SR;
	delete osc;
	delete lvl;
	delete freq;
}