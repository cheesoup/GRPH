#include <cmath>
#include <libraries/math_neon/math_neon.h>
#include <stdlib.h>
#include "filter.h"

#define ROOTPI sqrt(M_PI) * 0.5

filter::filter(float sr)
{
	setup(sr);
}

void filter::setup(float sr)
{
	sr_ = sr;
	cutoff_ = sr / 4.0;
	resonance_ = 0.0;
	buffer_[0] = 0.0;
	buffer_[1] = 0.0;
	buffer_[2] = 0.0;
	buffer_[3] = 0.0;	
}

void filter::setCutoff(float c)
{
	cutoff_ = (c * 2 * M_PI) / (sr_ * 4.0);
}

void filter::setResonance(float r)
{
	resonance_ = r;
}

float filter::process(float in)
{
	float fb = buffer_[3] * resonance_ * 4.0;
	fb = fminf(1.0, fmaxf(-1.0, fb));
	in = in - fb;
	buffer_[0] = ((in - buffer_[0]) * cutoff_) + buffer_[0];
	buffer_[1] = ((buffer_[0] - buffer_[1]) * cutoff_) + buffer_[1];
	buffer_[2] = ((buffer_[1] - buffer_[2]) * cutoff_) + buffer_[2];
	buffer_[3] = ((buffer_[2] - buffer_[3]) * cutoff_) + buffer_[3];
	
	float out = buffer_[3] * (1.0  + resonance_ * 4.0);
	return (2.0 / (1.0 + expf_neon(-out - 2.0*out*out*out/12.0 - 2.0*out*out*out*out*out/80.0))) - 1.0;
}